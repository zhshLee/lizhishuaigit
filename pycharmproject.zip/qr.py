import requests
from bs4 import BeautifulSoup
import bs4
import openpyxl
import sqlite3

conn = sqlite3.connect('UnivList.xlsx')
c = conn.cursor()


def getHTMLText(url):
    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        return ""


def fillUnivList(ulist, html):
    soup = BeautifulSoup(html, "html.parser")
    #for tr in soup.find_all("div", {"class": "rank-list__item clearfix"}):
    for tre in soup.find_all('tr'):
        if isinstance(tre, bs4.element.Tag):
            tds = tre.contents
            ulist.append(tds[1].contents+tds[3].contents[0].contents+tds[4].contents)


def saveUnivListoxlsx(ulist, num):
    # 创建一个空的xlxs工作簿文件
    wb = openpyxl.Workbook()

    # 获取活动工作表，并重命名
    ws1 = wb.active
    ws1.title = "大学排名"
    for i in range(num):
        u = ulist[i]
        ws1["A%d" % (i + 1)] = i+1
        ws1["B%d" % (i + 1)] = u[1]
        ws1["C%d" % (i + 1)] = u[2]

    wb.save(filename="UnivList.xlsx")


def hanshu(ulist, num):
    conn = sqlite3.connect('stuexample.db')
    c = conn.cursor()    # 获取连接的cursor，只有获取了cursor，我们才能进行各种操作
    print("Opened database successfully")

    # 此处插入数据库操作语句

    # 创建一个数据表 writers(id,name)
    c.execute('create table catalog (id char(8),pid varchar(8),name char(10))')
    for i in range(num):
        u = ulist[i]
        sqlstring = "insert into catalog values('%s','%s','%s')" % (u[0], u[1], u[2])
        c.execute(sqlstring)

    conn.commit()
    print("Records created successfully")
    #c.execute("select * from catalog")#打印数据库文件表检查对不对
    #print(c.fetchall())
    conn.close()


def main():
    uinfo = []
    url = 'https://123fans.cn/rank.php?c=2'
    html = getHTMLText(url)
    fillUnivList(uinfo, html)
    saveUnivListoxlsx(uinfo,100)
    hanshu(uinfo, 100)


main()