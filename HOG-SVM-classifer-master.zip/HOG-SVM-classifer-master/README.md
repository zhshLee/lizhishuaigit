# HOG-SVM-classifer
For  the CIFAR-10 dataset, extracting HOG features and using SVM classifier to classify them, at last, we get the accuracy.
Step 1 : You need to add some packages, and it's easy to do.
Step 2 : Load the data set at "http://www.cs.toronto.edu/~kriz/cifar.html"
Step 3 : Change the file path to your path saving your data.
